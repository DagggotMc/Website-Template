let credit = ("Please Leave credit to me if you use my template and downloading this relly helps")
alert(credit)